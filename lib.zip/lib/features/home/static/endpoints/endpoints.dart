import 'package:clinikk/flavor_config.dart';

class PostEndpoints {
  static String posts = '${FlavorHandler.currFlavor.baseUrl}/posts';
}
