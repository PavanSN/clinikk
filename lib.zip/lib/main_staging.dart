import 'package:clinikk/app/app.dart';
import 'package:clinikk/bootstrap.dart';

void main() {
  bootstrap(() => const MyApp());
}
